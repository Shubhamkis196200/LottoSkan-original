export default {
  items: [
    // {
    //   name: 'Users',
    //   url: '/users',
    //   icon: 'fa fa-users',
    // },
    {
      name: "Lotteries",
      url: "/lottery",
      icon: "fa fa-ticket",
    },
    {
      name: "Report",
      url: "/report",
      icon: "fas fa-server",
    },
    {
      name: "Settings",
      url: "/setting",
      icon: "fa fa-cog",
    },

    // {
    //   name: 'Settings',
    //   url: '/settings',
    //   icon: 'fas fa-cog',
    //   children: [
    //     // {
    //     //   name: 'CMS',
    //     //   url: '/settings/content-management',
    //     // },
    //     {
    //       name: 'General Setting',
    //       url: '/settings/general',
    //     },
    //   ],
    // },
  ],
};
