import React from "react";

export const index = () => {
  return <div>Membership</div>;
};
