 //String BASEURL = "http://dev.saturncube.com:8060/",

 /*String BASEURL = "http://api.lottoskan.pl/",
    // api/v2/scan/app
    LOTTOLISTURL = "api/v2/lottery/app?",
    LOTTOTICKET = 'api/v2/scan/app',
    DATELIST = "api/v2/winner/admin/date";*/



//String BASEURL = "http://dev.saturncube.com:8060/",
String BASEURL = "http://api.lottoskan.com/",
    SETTING = "api/v3/admin/setting",
    LOTTOLISTURL = "api/v3/lottery/app",
    LOTTOTICKET = 'api/v3/scan/app',
    DATELIST = "api/v3/winner/admin/date";


