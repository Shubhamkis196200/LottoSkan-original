/*
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:lotto_app/Common/Colors.dart';
import 'confirm_result_screen.dart';

class AdScreen extends StatefulWidget {
  const AdScreen({Key? key}) : super(key: key);

  @override
  State<AdScreen> createState() => _AdScreenState();
}

class _AdScreenState extends State<AdScreen> {

  //members
  //ad
  // RewardedAd? rewardedAd;


  String? textError;
  //load ad
  @override
  void initState(){
    super.initState();
    // loadAds();
  }


  // TODO: Add _rewardedAd
  // RewardedAd? _rewardedAd;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: blue,
      body: Center(
          child:*/
/* CircularProgressIndicator(
            color: yellow,
          )*//*

          InkWell(
            onTap: (){
            },
              child: Text('$textError', style: TextStyle(fontSize: 18)))
      )
    );
  }
}
*/
