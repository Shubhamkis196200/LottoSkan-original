import 'dart:ui';

import 'package:flutter/material.dart';

var yellow = Color(0xFFFED431);
var red = Color(0xFFFF8381);
var green = Color(0xFF2ECC71);
var darkblue = Color(0xFF242D86);
var cardColor = Color(0xff0090C1);
var lightblue = Color(0xFF0090C1);//Colors.black12;
var blue = Color(0xFF00ADE8);
var orange = Color(0xFFED7E24);
var lightblack = Color(0xFF987F1D);
var black = Colors.black;
var white = Colors.white;

