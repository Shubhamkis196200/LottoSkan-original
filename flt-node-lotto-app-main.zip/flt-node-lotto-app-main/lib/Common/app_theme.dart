import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'Colors.dart';


// TextStyle ==>
var headline = TextStyle(color: lightblack,fontWeight: FontWeight.bold,fontSize: 22);
var title = TextStyle(color: white,fontSize: 18,fontWeight: FontWeight.w600,);
var title2 = TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: black);
var subtitle = TextStyle(color: white,fontSize: 17,fontWeight: FontWeight.w500);
var subtitle2 = TextStyle(color: black,fontWeight: FontWeight.w500);
