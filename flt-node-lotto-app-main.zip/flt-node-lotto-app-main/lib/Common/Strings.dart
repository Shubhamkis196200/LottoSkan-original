///**********************************IMAGES**********************************///

String logo = "Assets/Lotto.png";
String lottoSkan = "Assets/LottoSkan.png";
String splash = "Assets/Splash.png";

String lotto = "lotto.png";
String lottoplus = "lotto_plus.png";
String eurojackpot = "euro_jackpot.png";
String multi = "multi_multi.png";
String multiplus = "multi_multi_plus.png";
String miniLotto = "mini_lotto.png";
String ekastraPensja = "ekstra_pensja.png";
String ekstraPensiaPremia = "ekstra_pensja_ekstra_premia.jpg";

String superSzansa = "Assets/SuperSzansa.png";
String szybkie600 = "Assets/szybkie600.png";
String zdrapki = "Assets/zdrapki.png";
String delete = "Assets/delete.png";
String SplashScreen = "Assets/SplashScreen.png";
String back = "Assets/back.png";
String coin = "Assets/coin.png";
String leaf = "Assets/leaf.png";

///********************************STRINGS***********************************///
// String wybierzgre = "Wybierz grę";
// String lottoText = "Lotto";
// String skan = "Skan";
// String wynik = "Wynik";
// String Skanujponownie = 'Skanuj ponownie';
// String confirmation = 'Confirmation';
// String congrats = "2 matches ! Congratulations,\n You won 10 USD !!";
// String congrats2 = "6 Matches ! Congratulations, \n You won the Jackpot 100.00 USD !!";
// String luck = "Better luck next time";
// String confirmresult = "Please confirm scanning result and submit it to know\nyour luck :)";
// String mistake = "If you find any mistake then feel free to correct and\nthen submit";
// String selectOption = "Select Option";
// String Gallery = "Gallery";
// String camera = "Camera";
// String cancel = "Cancel";
// String unableToScan = 'Unable to scan ticket';
// String maximumFields = 'You can add maximum tan fields';
// String SuperSzanza = '+Super Szanza';
// String yesShowMeResult = 'Yes All Good, Show me result';
// String addMore = 'Add more';


